public class StudentMiner extends Miner {
   
   public StudentMiner(Block genesisBlock) {
      super(genesisBlock);
   }
}